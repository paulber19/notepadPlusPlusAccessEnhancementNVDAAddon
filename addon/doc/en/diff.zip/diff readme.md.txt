readme.md
diff between version 2.6 (<) and version 2.7 (>)
This file should not be translated. It is only used for the gitHub repository.
11c11
<  * Latest version of NVDA tested: 2024.1
---
>  * Latest version of NVDA tested: 2024.4
71c71
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.6.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.7.nvda-addon
