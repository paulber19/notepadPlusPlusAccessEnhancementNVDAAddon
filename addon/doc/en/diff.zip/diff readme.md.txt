readme.md
diff between version 2.5.2 (<) and version 2.6 (>)
This file should not be translated. It is only used for the gitHub repository.
10,11c10,11
<  * Minimum NVDA version required: 2022.1
<  * Latest version of NVDA tested: 2023.3
---
>  * Minimum NVDA version required: 2023.1
>  * Latest version of NVDA tested: 2024.1
71c71
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.5.2.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.6.nvda-addon
