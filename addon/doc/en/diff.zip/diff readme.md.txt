readme.md
diff between version 2.3 (<) and version 2.4 (>)
This file should not be translated. It is only used for the gitHub repository.

1c1
< # Notepad ++ text editor: accessibility enhancement #
---
> # Notepad++ text editor: accessibility enhancement #
9c9
< * Latest version of NVDA tested: 2022.3
---
> * Latest version of NVDA tested: 2023.1
15c15
< This extension aims to improve the accessibility of the Notepad ++ text editor and add functionalities to facilitate the editing of files used in Python language and files written in markdown language.
---
> This extension aims to improve the accessibility of the Notepad++ text editor and add functionalities to facilitate the editing of files used in Python language and files written in markdown language.
38c38
< - added navigation mode for titles, links, quotes.
---
> * added navigation mode for titles, links, quotes.
40a41,44
> For DSpellCheck Notepad++ plugin:
>  
> * reporting of spelling errors when moving from line to line
> 
52c56,57
< 	* no diction of path's backslashs.
---
> 	* no diction of path's backslashs,
> 	* reporting of spelling errors found by the DSpellCheck add-in (experimental).
56c61,62
< This extension has been tested with Notepad ++ version 7.71.
---
> This extension has been tested with Notepad++ version 8.4.
> 
60c66,67
< This extension uses and intercepts the shortcuts of Notepad ++ configured by default. It is therefore strongly advised, for its proper functioning, not to modify these shortcuts.
---
> This extension uses and intercepts the shortcuts of Notepad++ configured by default. It is therefore strongly advised, for its proper functioning, not to modify these shortcuts.
> 
62d68
< Note: this is an automatic translation from french language.
64c70
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.3.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.4.nvda-addon
