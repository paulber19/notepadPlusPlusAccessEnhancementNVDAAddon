readme.md
diff between version 2.4 (<) and version 2.5 (>)
This file should not be translated. It is only used for the gitHub repository.
2,3c2,3
< * Author: PaulBer19
< * URL: paulber19@laposte.net
---
> * Author: PaulBer19 (paulber19@laposte.net)
> * URL: [https://github.com/paulber19/notepadPlusPlusAccessEnhancementNVDAAddon.git] [3]
8,10c8,9
< * Minimum NVDA version required: 2020.4
< * Latest version of NVDA tested: 2023.1
< 
---
> * Minimum NVDA version required: 2022.1
> * Latest version of NVDA tested: 2023.2
42c41
<  
---
> 
61c60
< This extension has been tested with Notepad++ version 8.4.
---
> This extension has been tested with Notepad++ version 8.4 and 8.5.6.
70c69
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.4.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.5.nvda-addon
71a71
> [3]: https://github.com/paulber19/notepadPlusPlusAccessEnhancementNVDAAddon.git
