readme.md
diff between version 2.8 (<) and version 2.9 (>)
This file should not be translated. It is only used for the gitHub repository.
10,11c10,11
<  * Minimum NVDA version required: 2024.1
<  * Latest version of NVDA tested: 2025.1
---
>  * Minimum NVDA version required: 2025.1
>  * Latest version of NVDA tested: 2026.1
62c62
< This extension has been tested with Notepad++ version 8.4 and 8.5.6.
---
> This extension has been tested with Notepad++ version 8.8.3 64 bits
71c71
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.8.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement/notepadPlusPlusAccessEnhancement-2.9.nvda-addon
