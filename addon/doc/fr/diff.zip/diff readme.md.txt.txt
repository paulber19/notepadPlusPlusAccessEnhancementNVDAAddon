readme.md
diff entre version 2.3 (<) et version 2.4 (>)
Ce fichier est supprimé.  Seul le fichier en anglais est conservé et ne doit pas être traduit. Il n'est utilisé que pour le dépôt gitHub.
